<?php

define('baseurl','http://localhost/latihan_ukkamel/public');