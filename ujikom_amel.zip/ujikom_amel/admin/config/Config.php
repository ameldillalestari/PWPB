<?php

define('BASEURL','http://localhost/ujikom_amel/public');