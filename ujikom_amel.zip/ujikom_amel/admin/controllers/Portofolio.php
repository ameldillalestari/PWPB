<?php 

class Portofolio extends Controller{
    public function index()
    {
        $data['profile'] = $this->model('PortofolioModel');

        $this->view('portofolio/index',$data);
    }
    public function model($model)
    {
        require_once'../admin/models/'.$model.'.php';
        return new $model;
    }
}