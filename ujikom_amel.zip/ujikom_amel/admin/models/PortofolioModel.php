<?php

class PortofolioModel{
  private $host  =DB_HOST;
  private $user  =DB_USER;
  private $pass  =DB_PASS;
  private $db_name=DB_NAME;

  private $dbh;
  private $stmt;
  function __construct()
  {
          $dsn ='mysql:host='.$this->host.';dbname='.$this->db_name;
          $option = [
          PDO::ATTR_PERSISTENT => true,
          PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
          ];  
          try {
             $this->dbh = new PDO($DSN, $this->user, $this->pass, $option);
          }catch (PDOException $e) {
            die($e->getMessage());        
          }
  }
          public function __construct()
          {
public function getProfile()
          }


}