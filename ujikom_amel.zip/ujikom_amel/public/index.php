<?php 

require_once '../admin/init.php';

$app = new App();